﻿

namespace $safeprojectname$.Texts
{
    public static class SecureStorageKey
    {
        public const string IsDarkMode = "IsDarkMode";
    }
}
